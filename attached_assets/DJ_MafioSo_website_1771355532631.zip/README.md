# DJ MafioSo - Website Export

## What Is This?

This ZIP is a complete, ready-to-deploy website for **DJ MafioSo**, exported from Oraginal Concepts.

## How to Deploy

### Option 1: GoDaddy / Traditional Hosting
1. Log into your GoDaddy hosting account (or any web host with file manager / FTP)
2. Navigate to the public_html or www folder
3. Upload ALL files from this ZIP (keep the folder structure intact)
4. Your site should be live immediately

### Option 2: Render / Vercel / Netlify
1. Create a new "Static Site" project
2. Upload or connect these files
3. Set the publish directory to the root folder
4. Deploy

### Option 3: Import into a Replit Project
1. Create a new Replit project
2. Upload all files from this ZIP
3. Add your own backend server if needed
4. Connect to the client's services (database, email, payments, etc.)

## Contact Form

The contact form uses a mailto: link to open the visitor's email app. If you want a more advanced form that sends emails directly:

1. **Formspree** (free): Sign up at formspree.io, create a form, and replace the form's onsubmit handler with Formspree's action URL
2. **EmailJS** (free): Sign up at emailjs.com and follow their integration guide
3. **Custom backend**: Connect the form to your own server-side email handler

## Files Included

- **index.html** — The main website page with all branding applied
- **css/** — Stylesheets
- **js/** — JavaScript files
- **images/** — Template images
- **assets/** — Downloaded brand images (logo, hero, etc.)
- **brand-kit.json** — Raw brand data for reference

## About Oraginal Concepts

"Give Me Your Concept, Let's Make It Real."

Exported from [Oraginal Concepts](https://oraginalconcepts.com)
